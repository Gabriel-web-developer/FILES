import javax.swing.*;
import java.awt.event.*;

public class proyect1 extends JFrame implements ActionListener  {
    private JLabel label1;
    private JLabel label2;
    private JLabel label3;
    private JButton boton1, boton2, boton3, boton4;

    public proyect1() {
    setLayout(null);

    label1 = new JLabel("Interfaz Grafica");
    label1.setBounds(10, 20, 300, 30);
    add(label1);

    label2 = new JLabel("Version: 1.0");
    label2.setBounds(10, 100, 300, 30);
    add(label2);

    label3 = new JLabel("En espera...");
    label3.setBounds(10, 180, 200, 30);
    add(label3);

    boton1 = new JButton("1");
    boton1.setBounds(10, 250, 90, 20);
    boton1.addActionListener(this);
    add(boton1);

    boton2 = new JButton("2");
    boton2.setBounds(110, 250, 90, 20);
    boton2.addActionListener(this);
    add(boton2);

    boton3 = new JButton("3");
    boton3.setBounds(210, 250, 90, 20);
    boton3.addActionListener(this);
    add(boton3);

    boton4 = new JButton("Cerrar");
    boton4.setBounds(450, 400, 100, 30);
    boton4.addActionListener(this);
    add(boton4);


}

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == boton1) {
            label3.setText("Has presionado el boton 1");
        }else if (e.getSource() == boton2) {
            label3.setText("Has presionado el boton 2");
        }else if (e.getSource() == boton3){
            label3.setText("Has presionado el boton 3");
        }


        if (e.getSource() == boton4) {
            System.exit(0);
        }
    }

    public static void main(String args[]) {
        proyect1 app1 = new proyect1();
        app1.setBounds(0,0,600,500);
        app1.setVisible(true);
        app1.setResizable(false);
        app1.setLocationRelativeTo(null);

    }


}

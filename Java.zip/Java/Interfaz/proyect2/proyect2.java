import javax.swing.*;
import java.awt.event.*;

public class proyect2 extends JFrame implements ActionListener  {
    private JTextField textf1;
    private JButton boton1;
    private JLabel label1;
    public static String texto = "";

    public proyect2() {
        setLayout(null);
        label1 = new JLabel("Usuario: ");
        label1.setBounds(10, 10, 100, 30);
        add(label1);

        textf1 = new JTextField();
        textf1.setBounds(120, 17, 150, 20);
        add(textf1);

        boton1 = new JButton("Aceptar");
        boton1.setBounds(10, 80, 100, 30);
        boton1.addActionListener(this);
        add(boton1);
    }

    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == boton1){
            texto = textfield1.getText().trim();
            if(texto.equals("")){
              JOptionPane.showMessageDialog(null, "Debes ingresar tu nombre.");
            } else {
              Principal ventanaPrincipal = new Principal();
              ventanaPrincipal.setBounds(0,0,640,535);
              ventanaPrincipal.setVisible(true);
              ventanaPrincipal.setResizable(false);
              ventanaPrincipal.setLocationRelativeTo(null);
              this.setVisible(false);
            }
          }
    }

    public static void main(String args[]) {
        proyect2 app3 = new proyect2();
        app3.setBounds(0,0,300,160);
        app3.setVisible(true);
        app3.setResizable(false);
        app3.setLocationRelativeTo(null);

    }
}

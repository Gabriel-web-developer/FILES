import javax.swing.*;
import java.awt.event.*;

public class proyect3 extends JFrame implements ActionListener {
    private JButton boton1;
    private JTextField textField1;
    private JTextArea textArea1;
    private JScrollPane scrollPane1;

    String texto = "";

    public proyect3() {
        setLayout(null);
        textField1 = new JTextField();
        textField1.setBounds(10, 10, 200, 25);
        add(textField1);

        boton1 = new JButton("Agregar");
        boton1.setBounds(250, 10, 100, 25);
        boton1.addActionListener(this);
        add(boton1);
        
        textArea1 = new JTextArea();
        scrollPane1 = new JScrollPane(textArea1);
        scrollPane1.setBounds(10, 50, 400, 400);
        add(scrollPane1);

    }

    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == boton1) {
            texto += textField1.getText() + "\n";
            textArea1.setText(texto);
            textField1.setText("");
        }
    }

    
    public static void main(String args[]) {
        proyect3 app = new proyect3();
        app.setBounds(0,0,500,500);
        app.setVisible(true);
        app.setResizable(false);
        app.setLocationRelativeTo(null);
    }

    
}
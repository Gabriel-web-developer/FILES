import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class proyect5 extends JFrame implements ActionListener {
    private JMenuBar menubar;
    private JMenu menu1, menu2, menu3;
    private JMenuItem item1,item2,item3, item4;

    public proyect5(){
        setLayout(null);

        menubar = new JMenuBar();
        setJMenuBar(menubar);

        menu1 = new JMenu("Opciones");
        menubar.add(menu1);

        menu2 = new JMenu("Tamaño de la Ventana");
        menu1.add(menu2);

        menu3 = new JMenu("Color de fondo");
        menu1.add(menu3);

        item1 = new JMenuItem("300*200");
        item1.addActionListener(this);
        menu2.add(item1);

        item2 = new JMenuItem("600*400");
        item2.addActionListener(this);
        menu2.add(item2);

        item3 = new JMenuItem("Rojo");
        item3.addActionListener(this);
        menu3.add(item3);

        item4 = new JMenuItem("Azul");
        item4.addActionListener(this);
        menu3.add(item4);
    }


    public void actionPerformed(ActionEvent e){

        if(e.getSource() == item1){
            setSize(300,200);
        } else if (e.getSource() == item2) {
            setSize(600,400);
        }else if (e.getSource() == item3){
            getContentPane().setBackground(new Color(255,0,0));
        }else if (e.getSource() == item4){
            getContentPane().setBackground(new Color(0,0,255));
        }
    }

    public static void main(String[] args) {
        proyect5 app = new proyect5();
        app.setBounds(0,0,350,350);
        app.setVisible(true);
        app.setResizable(false);
        app.setLocationRelativeTo(null);
    }
}
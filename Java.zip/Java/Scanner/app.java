import java.sql.Array;
import java.util.Scanner;

public class app {
    public static void main(String[] args) { 

        Scanner in = new Scanner(System.in);

        /*


        //Primer hola mundo 
        
        System.out.println("");
        System.out.println("Hola mundo");
        System.out.println(""); 
        */

        /*
        // Sistema de saludo

        String name = "";

        System.out.println("Cual es tu nombre?");
        name = in.nextLine();
        System.out.println(""); 

        System.out.println("Hola " + name);

        */
        
        /*

        //sistema de control vacacional 

        String nombre = "";

        int clave = 0, antiguedad = 0;

        System.out.println(""); 
        System.out.println("***********************************************");
        System.out.println("* Bienvenido al sistema de control vacacional *");
        System.out.println("***********************************************");
        System.out.println(""); 

        System.out.println("Cual es tu nombre?"); 
        nombre = in.nextLine();
        System.out.println(""); 

        System.out.println("Cuanto tiempo de servicio tiene trabajando?");
        antiguedad = in.nextInt();
        System.out.println(""); 

        System.out.println("Cual es su clave ?"); 
        clave = in.nextInt();
        System.out.println(""); 

        if (clave == 1) {
            if (antiguedad == 1) {
                System.out.println("El trabajador " + nombre + " tiene derecho a 6 dias de vacaciones");
            } else if (antiguedad >= 2 && antiguedad <= 6) {
                System.out.println("El trabajador " + nombre + " tiene derecho a 14 dias de vacaciones");
            } else if (antiguedad >= 7) {
                System.out.println("El trabajador " + nombre + " tiene derecho a 20 dias de vacaciones");
            }


        } else if (clave == 2) {
            if (antiguedad == 1) {
                System.out.println("El trabajador " + nombre + " tiene derecho a 7 dias de vacaciones");
            } else if (antiguedad >= 2 && antiguedad <= 6) {
                System.out.println("El trabajador " + nombre + " tiene derecho a 15 dias de vacaciones");
            } else if (antiguedad >= 7) {
                System.out.println("El trabajador " + nombre + " tiene derecho a 20 dias de vacaciones");
            }
        } else if (clave == 3) {
            if (antiguedad == 1) {
                System.out.println("El trabajador " + nombre + " tiene derecho a 10 dias de vacaciones");
            } else if (antiguedad >= 2 && antiguedad <= 6) {
                System.out.println("El trabajador " + nombre + " tiene derecho a 20 dias de vacaciones");
            } else if (antiguedad >= 7) {
                System.out.println("El trabajador " + nombre + " tiene derecho a 30 dias de vacaciones");
            }
        } else {
            System.out.println("Error!, la clave de departamento es incorrecta"); 
        }

        */
             
        /* 

        // switch / case

        int numberOne = 0, numberTwo = 0, resultado = 0;
        int parametro = 0;

        System.out.println("Proporcioname un numero");
        numberOne = in.nextInt();
        System.out.println(""); 

        System.out.println("Proporcioname el otro numero");
        numberTwo = in.nextInt();
        System.out.println(""); 

        System.out.println("Que deseas hacer con estos numeros?");
        System.out.println("1 Sumarlos");
        System.out.println("2 Restarlos");
        System.out.println("3 Multiplicalos");
        System.out.println("4 dividirlos");
        System.out.println("");
        parametro = in.nextInt();
        System.out.println(""); 

        switch (parametro) {
            case 1: resultado = numberOne + numberTwo; 
                    System.out.println("el resultado de la suma es " + resultado);
                    break;

            case 2: resultado = numberOne - numberTwo; 
                    System.out.println("el resultado de la resta es " + resultado);
                    break;

            case 3: resultado = numberOne * numberTwo; 
                    System.out.println("el resultado de la multiplicacion es " + resultado);
                    break;

            case 4: resultado = numberOne / numberTwo; 
                    System.out.println("el resultado de la  division " + resultado);
                    break;

            default : System.out.println("Error!, la opcion no existe"); 
            break;
        }

        */

        /*

        // for (bucles  y ciclos)

        for (int i = 1; i <=5; i++) {
            System.out.print(i + ", ");
        }

         */

        /* 

        //while (blucles y ciclos)

        int e = 1;

        while (1 < 10) {
            System.out.print(e + ",");
            e=+2;
        }

        */

        /*
        
        // do-while (ciclos, bucles)
        
        int a = 1000;

        do{
            System.out.print(i + ", ");
            
            a-=200;
        }while (a >= 0);

        */
        
        /*

        // comparacion de nombres

        String nameOne = "", nameTwo = "";

        System.out.print("Por favor ingresa el primer nombre: ");
        nameOne = in.nextLine();
        System.out.println("");

        System.out.print("Por favor ingresa el segundo nombre: ");
        nameTwo = in.nextLine();
        System.out.println("");

        if (nameOne.equalsIgnoreCase(nameTwo) ){
            System.out.println("Los nombres coinciden");
            System.out.println(""); 
        } else {
            System.out.println("Los nombre no coinciden");
            System.out.println(""); 
        }

         */

        /*
        
        // login cmd 

        String usuario = "", password  = "";

        System.out.print("Ingrese el nombre de usuario: ");
        usuario = in.nextLine();

        System.out.print("Ingresa el password: ");
        password = in.nextLine();
        System.out.println("");

        if (usuario.equalsIgnoreCase("gabriel") && password.equalsIgnoreCase("123456")  ){

            System.out.println("Accseso correcto");

        }else {
            System.out.println("Accseso incorrecto");
        }

         */

        /* 

        // manipulacion de cadenas de texto

        String cadenaOrigin = "", cadenaSubstraccion = "";
        int numberCadena = 0, desde = 0, hasta = 0;

        System.out.println("");
        System.out.print("Introduce una cadena de texto: ");
        cadenaOrigin = in.nextLine();
        System.out.println("");

        numberCadena = cadenaOrigin.length();

        System.out.println("la cadena de texto " + cadenaOrigin + " contiene " + numberCadena + " caracteres");
        System.out.println("");

        System.out.println("Desde que caracter deseas obtener la nueva cadena?: ");
        desde = in.nextInt();
        System.out.println("");

        System.out.println("hasta que caracter deseas obtener la nueva cadena?: ");
        hasta = in.nextInt();
        System.out.println("");
        
        cadenaSubstraccion = cadenaOrigin.substring(desde, hasta);
        System.out.println("La nueva cadena es: " + cadenaSubstraccion);

        */

        /*

        // array (listas de objetos)

        int array [] = new int[5];

        array[0] = 10;
        array[1] = 20;
        array[2] = 30;
        array[3] = 40;
        array[4] = 50;

        System.out.print("[" + array[0] + "], ");
        System.out.print("[" + array[1] + "], ");
        System.out.print("[" + array[2] + "], ");
        System.out.print("[" + array[3] + "], ");
        System.out.print("[" + array[4] + "]");

         */
          

    } 
}